long some_function();
/* int */ other_function();
 
/* int */ calling_function()
{
    long test1;
    register /* int */ test2;
 
    test1 = some_function();
    if (test1 > 0)
          test2 = 0;
    else
          test2 = other_function();
    return test2;
}